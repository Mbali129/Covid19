package com.example.covid19

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class LoginActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var button: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
         button=findViewById<Button>(R.id.login)
        val signup =findViewById<Button>(R.id.signup)
        val email=findViewById<TextView>(R.id.email)
        val password=findViewById<TextView>(R.id.password)
        // Initialize Firebase Auth
        auth = Firebase.auth
        button.setOnClickListener {
           this.login(email.text.toString(),password.text.toString())
            button.text= "Processing"
        }
        signup.setOnClickListener {
            startActivity(Intent(this, SignupActivity::class.java))
        }

    }
    public override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser = auth.currentUser
        if(currentUser != null){
            reload();
        }
    }

    private fun reload() {
        TODO("Not yet implemented")
    }

    fun login(email:String,password:String){
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                button.text="login"
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d("SANELE", "signInWithEmail:success")
                    val user = auth.currentUser
                    startActivity(Intent(this, ProfileActivity::class.java))
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w("SANELE", "signInWithEmail:failure", task.exception)
                    Toast.makeText(baseContext, "Authentication failed.",
                        Toast.LENGTH_SHORT).show()

                }

            }

    }
}